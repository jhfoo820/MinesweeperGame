import java.util.*;

import javax.swing.ImageIcon;

public class BombSquare extends GameSquare
{

	public int bombcount;
	public boolean isClicked = false;
	private boolean thisSquareHasBomb = false;
	public static final int MINE_PROBABILITY = 10;
	private int[] checkX = {-1, 0, 1};
	private int[] checkY = {-1, 0, 1};
	private int boardheight = (board.getHeight() - 20) / 20;
	private int boardwidth = (board.getWidth() - 20) / 20;
	
	public BombSquare(int x, int y, GameBoard board)
	{
		super(x, y, "images/blank.png", board);
		Random r = new Random();
		thisSquareHasBomb = (r.nextInt(MINE_PROBABILITY) == 0);
	}

	public int CountBomb() 
	{
		bombcount = 0;
		for (int i = -1; i < 2; i++)			
		{
			for (int j = -1; j < 2; j++)
			{
				BombSquare a = (BombSquare) board.getSquareAt(this.xLocation + i, this.yLocation + j);
				if (a != null && a.thisSquareHasBomb)
				{
					bombcount++;
				}
			}
		}
		return bombcount;
	}

	public void setWhiteSpace()
	{
		for (int x : checkX) 
		{
			for (int y : checkY) 
			{
				BombSquare b = (BombSquare) board.getSquareAt(this.xLocation + x, this.yLocation + y);
				if (reachedBoundary(this.xLocation + x, this.yLocation + y))
				{
					return;
				} 
				else
				{
					b.setImage("images/0.png");
					isClicked = true;
				}
			}
	}
	}

	private boolean reachedBoundary(int x, int y)
    {
        return x < 0 || x >= boardwidth || y < 0 || y >= boardheight;
    }
			
	public void clicked()
	{
		if(!isClicked)
		{
			if (thisSquareHasBomb)
			{
				setImage("images/bomb.png");
				isClicked = true;
			} 
			else if (CountBomb() == 0) 
			{ 
				setWhiteSpace();
			}
			else if (CountBomb() > 0) 
			{
				setImage("images/" + CountBomb() + ".png");
				isClicked = true;
			}
		}
	}	
}
